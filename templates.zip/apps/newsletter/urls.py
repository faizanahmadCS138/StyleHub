# apps/newsletter/urls.py

from django.urls import path
from . import views

app_name = 'newsletter'

urlpatterns = [
    path('subscribe/', views.subscribe, name='subscribe'),
    path(
        'unsubscribe/<uuid:token>/',
        views.unsubscribe,
        name='unsubscribe'
    ),
]